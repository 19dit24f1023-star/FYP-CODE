<?php 

$conn = mysqli_connect("localhost", "root", "", "sa_design");
  
  if(!$conn){
	  die("Connection failed: ". mysqli_connect_error());
  }
  ?>