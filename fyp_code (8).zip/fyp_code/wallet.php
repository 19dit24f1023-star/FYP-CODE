<?php
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/toyyibpay_create_bill.php';

if (!isset($_SESSION['customer_id']) && !isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$customerId = (int)($_SESSION['customer_id'] ?? $_SESSION['user_id']);
$message = '';

$account = $conn->prepare('INSERT IGNORE INTO wallet_accounts (customer_id) VALUES (?)');
$account->bind_param('i', $customerId);
$account->execute();
$account->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = round((float)($_POST['amount'] ?? 0), 2);
    if ($amount < 5 || $amount > 10000) {
        $message = 'Top ups must be between RM 5.00 and RM 10,000.00.';
    } else {
        $customerStmt = $conn->prepare('SELECT name, email, phone_number FROM customers WHERE id = ? LIMIT 1');
        $customerStmt->bind_param('i', $customerId);
        $customerStmt->execute();
        $customer = $customerStmt->get_result()->fetch_assoc();
        $customerStmt->close();
        $reference = 'WT-' . $customerId . '-' . date('YmdHis') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $pending = 'pending';
        $tx = $conn->prepare('INSERT INTO wallet_transactions (customer_id,type,amount,reference,status,description) VALUES (?,\'topup\',?,?,?,?)');
        $description = 'Wallet top up';
        $tx->bind_param('idsss', $customerId, $amount, $reference, $pending, $description);
        if (!$tx->execute()) {
            $message = 'Unable to start the top up.';
        }
        $tx->close();
        if ($message === '' && $customer) {
            $bill = createToyyibPayBill($reference, $customer['name'], $customer['email'], $customer['phone_number'], $amount, 'Online banking / FPX');
            if (!empty($bill['success'])) {
                $update = $conn->prepare('UPDATE wallet_transactions SET description = ? WHERE reference = ?');
                $billDescription = 'Wallet top up bill ' . $bill['billcode'];
                $update->bind_param('ss', $billDescription, $reference);
                $update->execute();
                $update->close();
                header('Location: ' . $bill['payment_url']);
                exit;
            }
            $failed = 'failed';
            $update = $conn->prepare('UPDATE wallet_transactions SET status = ? WHERE reference = ?');
            $update->bind_param('ss', $failed, $reference);
            $update->execute();
            $update->close();
            $message = $bill['message'] ?? 'Unable to create the payment bill.';
        }
    }
}

$balanceStmt = $conn->prepare('SELECT balance FROM wallet_accounts WHERE customer_id = ?');
$balanceStmt->bind_param('i', $customerId);
$balanceStmt->execute();
$balance = (float)($balanceStmt->get_result()->fetch_assoc()['balance'] ?? 0);
$balanceStmt->close();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Wallet | SA Design</title><link rel="stylesheet" href="ui_polish.css"><style>body{font-family:Arial;background:#f6e8f2;margin:0}.card{max-width:520px;margin:70px auto;background:#fff;padding:32px;border-radius:20px;box-shadow:0 15px 40px #1c35761c}h1{color:#102f91}.balance{font-size:34px;color:#f0208d;font-weight:800;background:#fff3fa;padding:20px;border-radius:14px}label{display:block;margin:20px 0 7px;font-weight:bold}input,button{width:100%;box-sizing:border-box;padding:13px;border-radius:10px;border:1px solid #d0c5d5}button{margin-top:18px;background:#f0208d;color:#fff;border:0;font-weight:bold;cursor:pointer}.error{color:#c21d67;margin-top:15px}a{display:block;margin-top:18px;color:#1747c7;text-align:center}</style></head><body><main class="card"><h1>My Wallet</h1><div class="balance">RM <?= number_format($balance,2) ?></div><?php if($message): ?><p class="error"><?= htmlspecialchars($message) ?></p><?php endif; ?><form method="post"><label for="amount">Top up amount (RM)</label><input id="amount" name="amount" type="number" min="5" max="10000" step="0.01" required><button type="submit">Top up with ToyyibPay</button></form><a href="cust_profile.php">Back to my account</a></main></body></html>
