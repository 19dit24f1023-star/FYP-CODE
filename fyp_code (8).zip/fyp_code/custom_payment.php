<?php
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/toyyibpay_create_bill.php';

if (!isset($_SESSION['customer_id'])) {
    header('Location: index.php');
    exit;
}

$customerId = (int)$_SESSION['customer_id'];
$requestId = (int)($_GET['id'] ?? $_POST['request_id'] ?? 0);
$message = '';
$request = null;

$stmt = $conn->prepare('SELECT * FROM custom_request WHERE id = ? AND email = (SELECT email FROM customers WHERE id = ?) LIMIT 1');
if ($stmt) {
    $stmt->bind_param('ii', $requestId, $customerId);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$request || !isset($request['price']) || !is_numeric($request['price']) || (float)$request['price'] <= 0) {
    http_response_code(404);
    exit('Quotation not available.');
}

if (strcasecmp((string)($request['payment_status'] ?? 'Pending'), 'Paid') === 0) {
    header('Location: cust_profile.php?page=custom');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentMethod = trim($_POST['payment_method'] ?? '');
    if (!in_array($paymentMethod, ['FPX', 'DuitNow QR'], true)) {
        $message = 'Please select a valid payment method.';
    } else {
        $reference = 'CR' . str_pad((string)$requestId, 5, '0', STR_PAD_LEFT);
        $bill = createToyyibPayBill(
            $reference,
            $request['fullname'],
            $request['email'],
            $request['phone'],
            (float)$request['price'],
            $paymentMethod
        );

        if (!$bill['success']) {
            $message = $bill['message'];
        } else {
            $update = $conn->prepare('UPDATE custom_request SET payment_method = ?, payment_status = ?, toyyibpay_billcode = ? WHERE id = ?');
            $pending = 'Pending';
            if (!$update) {
                exit('Unable to prepare payment update.');
            }
            $update->bind_param('sssi', $paymentMethod, $pending, $bill['billcode'], $requestId);
            if (!$update->execute()) {
                $update->close();
                exit('Unable to save payment details.');
            }
            $update->close();
            header('Location: ' . $bill['payment_url']);
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Payment | SA Design</title>
    <link rel="stylesheet" href="ui_polish.css">
    <style>
        body{margin:0;min-height:100vh;background:#f6e8f2;font-family:Arial,sans-serif;display:flex;align-items:center;justify-content:center}
        .payment-card{width:min(480px,calc(100% - 40px));background:#fff;border-radius:20px;padding:30px;box-shadow:0 18px 50px rgba(30,50,100,.12)}
        h1{margin:0 0 8px;color:#102f91}.muted{color:#64748b;font-size:13px}.amount{margin:20px 0;padding:16px;border-radius:12px;background:#fff3fa;color:#f0208d;font-size:24px;font-weight:800}
        label{display:block;margin:15px 0 8px;color:#35445d;font-weight:700;font-size:13px}.method{display:flex;gap:10px}.method label{flex:1;margin:0;padding:14px;border:1px solid #d7dff0;border-radius:11px;cursor:pointer}.method input{margin-right:6px}
        button{width:100%;margin-top:22px;padding:13px;border:0;border-radius:11px;background:#f0208d;color:#fff;font-weight:800;cursor:pointer}.error{padding:10px;border-radius:10px;background:#fff0f4;color:#c21d67;font-size:12px}
        a{display:block;text-align:center;margin-top:15px;color:#1747c7;font-size:12px;text-decoration:none}
    </style>
</head>
<body>
    <main class="payment-card">
        <h1>Make Payment</h1>
        <p class="muted">Custom Request #CR<?php echo str_pad((string)$requestId, 3, '0', STR_PAD_LEFT); ?> · <?php echo htmlspecialchars($request['product_name']); ?></p>
        <div class="amount">RM <?php echo number_format((float)$request['price'], 2); ?></div>
        <?php if ($message !== ''): ?><div class="error"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
            <label>Payment Method</label>
            <div class="method">
                <label><input type="radio" name="payment_method" value="FPX" required> FPX</label>
                <label><input type="radio" name="payment_method" value="DuitNow QR" required> DuitNow QR</label>
            </div>
            <button type="submit"><i class="fa-solid fa-lock"></i> Proceed to Payment</button>
        </form>
        <a href="cust_profile.php?page=custom">Back to Custom Requests</a>
    </main>
</body>
</html>
