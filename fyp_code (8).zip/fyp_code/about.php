<?php session_start(); $loggedIn = isset($_SESSION["is_logged_in"]) && $_SESSION["is_logged_in"] === true; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | SA Design</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@500;600;700&display=swap" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f6e8f2;
            color: #172033;
            min-height: 100vh;
        }

        a { text-decoration: none; }

        /* ==================== NAVBAR ==================== */
        .navbar {
            min-height: 84px;
            padding: 16px 48px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            background: #fff;
            border-bottom: 1px solid #e8ebf2;
            box-shadow: 0 4px 18px rgba(28, 53, 118, .05);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .logo {
            display: flex;
            flex-direction: column;
            line-height: .95;
        }

        .logo-main {
            display: flex;
            align-items: baseline;
            gap: 7px;
            font-size: 32px;
            font-weight: 900;
            letter-spacing: -2px;
        }

        .logo-sa { color: #f0208d; }
        .logo-design { color: #1557d6; }

        .logo-subtitle {
            margin-top: 4px;
            color: #111827;
            font-size: 9px;
            font-weight: 900;
            letter-spacing: .9px;
            text-transform: uppercase;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .nav-links a {
            color: #111827;
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
            transition: .2s;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #f0208d;
        }

        .nav-user-icon {
            width: 42px;
            height: 42px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #f0208d;
            border-radius: 50%;
            color: #f0208d;
            font-size: 19px;
            transition: .2s;
        }

        .nav-user-icon:hover {
            transform: translateY(-2px);
            background: #ffe4f2;
        }

        .menu-toggle {
            display: none;
            width: 42px;
            height: 42px;
            border: 1px solid #dfe4ef;
            border-radius: 11px;
            background: #fff;
            color: #172033;
            cursor: pointer;
        }

        /* ==================== ABOUT HERO ==================== */
        .about-hero {
            position: relative;
            overflow: hidden;
            padding: 78px 70px 72px;
            background: linear-gradient(120deg, #b7c8ff 0%, #d9b9eb 52%, #ffc0dc 100%);
            border-bottom: 1px solid #e0e7f8;
        }

        .about-hero::before {
            content: "";
            position: absolute;
            width: 300px;
            height: 300px;
            right: -90px;
            top: -150px;
            border-radius: 50%;
            background: rgba(40, 84, 197, .20);
        }

        .about-hero::after {
            content: "";
            position: absolute;
            width: 220px;
            height: 220px;
            left: -90px;
            bottom: -130px;
            border-radius: 50%;
            background: rgba(239, 58, 155, .20);
        }

        .about-hero-content {
            position: relative;
            z-index: 2;
            max-width: 1050px;
            margin: auto;
            text-align: center;
        }

        .section-badge {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 14px;
            border-radius: 999px;
            background: #fff;
            border: 1px solid #dbe4ff;
            color: #1747c7;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .7px;
        }

        .about-hero h1 {
            margin: 15px 0 10px;
            color: #102f91;
            font-size: clamp(35px, 5vw, 52px);
            font-weight: 900;
            letter-spacing: -2px;
        }

        .about-hero h1 span {
            color: #f0208d;
        }

        .about-hero p {
            max-width: 720px;
            margin: auto;
            color: #64748b;
            font-size: 14px;
            line-height: 1.7;
        }

        /* ==================== MAIN INFO ==================== */
        main {
            width: min(1120px, calc(100% - 140px));
            margin: 55px auto;
        }

        .section-title {
            text-align: center;
            margin-bottom: 28px;
        }

        .section-title h2 {
            margin-top: 11px;
            color: #102f91;
            font-size: 30px;
            font-weight: 900;
            letter-spacing: -1px;
        }

        .section-title p {
            margin-top: 6px;
            color: #64748b;
            font-size: 13px;
        }

        .about-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .info-card {
            position: relative;
            overflow: hidden;
            min-height: 225px;
            padding: 27px 23px;
            background: #fff;
            border: 1px solid #e4e8f2;
            border-radius: 20px;
            box-shadow: 0 9px 23px rgba(28, 53, 118, .06);
            transition: .25s;
        }

        .info-card::after {
            content: "";
            position: absolute;
            width: 90px;
            height: 90px;
            right: -35px;
            bottom: -35px;
            border-radius: 50%;
            background: rgba(239, 58, 155, .07);
        }

        .info-card:hover {
            transform: translateY(-5px);
            border-color: #b7c8ff;
            box-shadow: 0 17px 32px rgba(28, 53, 118, .11);
        }

        .info-icon {
            width: 46px;
            height: 46px;
            display: grid;
            place-items: center;
            margin-bottom: 17px;
            border-radius: 13px;
            background: #cddaff;
            color: #1747c7;
            font-size: 19px;
        }

        .info-card:nth-child(2) .info-icon {
            background: #ffc9df;
            color: #f0208d;
        }

        .info-card:nth-child(3) .info-icon {
            background: #dff5ed;
            color: #07966c;
        }

        .info-card h2 {
            margin-bottom: 12px;
            color: #102f91;
            font-size: 18px;
            font-weight: 900;
        }

        .info-card p {
            position: relative;
            z-index: 1;
            color: #64748b;
            font-size: 12px;
            line-height: 1.7;
            margin-bottom: 10px;
        }

        /* ==================== LOCATION + CONTACT ==================== */
        .bottom-grid {
            display: grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 20px;
            margin-top: 22px;
        }

        .content-card {
            padding: 27px;
            background: #fff;
            border: 1px solid #e4e8f2;
            border-radius: 20px;
            box-shadow: 0 9px 23px rgba(28, 53, 118, .06);
        }

        .content-card h2 {
            margin-bottom: 17px;
            color: #102f91;
            font-size: 19px;
            font-weight: 900;
        }

        .content-card iframe {
            width: 100%;
            height: 330px;
            border: 0;
            border-radius: 14px;
            display: block;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 13px 0;
            border-bottom: 1px solid #e1dce7;
        }

        .contact-item:last-child { border-bottom: 0; }

        .contact-icon {
            flex-shrink: 0;
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: #cddaff;
            color: #1747c7;
        }

        .contact-item:nth-child(3) .contact-icon {
            background: #ffc9df;
            color: #f0208d;
        }

        .contact-item:nth-child(4) .contact-icon {
            background: #dff5ed;
            color: #07966c;
        }

        .contact-item strong {
            display: block;
            margin-bottom: 3px;
            color: #172033;
            font-size: 11px;
        }

        .contact-item span,
        .contact-link {
            color: #64748b;
            font-size: 11px;
            line-height: 1.6;
        }

        .contact-link:hover { color: #f0208d; }

        /* ==================== CTA ==================== */
        .about-cta {
            position: relative;
            overflow: hidden;
            margin-top: 22px;
            padding: 28px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            border-radius: 20px;
            background: linear-gradient(120deg, #cddaff, #ffc9df);
            border: 1px solid #b7c8ff;
        }

        .about-cta h3 {
            color: #102f91;
            font-size: 18px;
            font-weight: 900;
            margin-bottom: 5px;
        }

        .about-cta p {
            color: #64748b;
            font-size: 11px;
        }

        .cta-button {
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 18px;
            border-radius: 12px;
            background: #1747c7;
            color: #fff;
            font-size: 11px;
            font-weight: 800;
            transition: .25s;
        }

        .cta-button:hover {
            transform: translateY(-3px);
            background: #f0208d;
        }

        /* ==================== FOOTER ==================== */
        footer {
            margin-top: 0;
            padding: 38px 70px;
            background: #0f1f61;
            color: #fff;
        }

        .footer-grid {
            width: min(1120px, 100%);
            margin: auto;
            display: grid;
            grid-template-columns: 1.5fr 1fr 1fr;
            gap: 35px;
        }

        .footer-brand {
            font-size: 24px;
            font-weight: 900;
        }

        .footer-brand span { color: #f0208d; }

        footer h4 {
            margin-bottom: 10px;
            font-size: 12px;
        }

        footer p,
        footer a {
            color: rgba(255,255,255,.72);
            font-size: 11px;
            line-height: 1.7;
        }

        footer a {
            display: block;
            margin-bottom: 4px;
        }

        footer a:hover { color: #fff; }

        .footer-line {
            width: min(1120px, 100%);
            margin: 24px auto 0;
            padding-top: 14px;
            border-top: 1px solid rgba(255,255,255,.14);
            text-align: center;
            color: rgba(255,255,255,.58);
            font-size: 10px;
        }

        /* ==================== RESPONSIVE ==================== */
        @media (max-width: 900px) {
            .navbar { padding: 15px 28px; }
            .about-grid { grid-template-columns: 1fr; }
            .bottom-grid { grid-template-columns: 1fr; }
            main { width: min(100% - 56px, 720px); }
        }

        @media (max-width: 760px) {
            .navbar {
                min-height: 76px;
                flex-wrap: wrap;
                padding: 15px 20px;
            }

            .logo-main { font-size: 28px; }

            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .nav-user-icon {
                width: 40px;
                height: 40px;
            }

            .nav-links {
                display: none;
                order: 5;
                width: 100%;
                padding: 13px 0 2px;
                flex-direction: column;
                gap: 14px;
                border-top: 1px solid #eef1f6;
            }

            .navbar.menu-open .nav-links { display: flex; }

            .about-hero {
                padding: 55px 22px;
            }

            .about-hero h1 {
                font-size: 38px;
            }

            main {
                width: calc(100% - 40px);
                margin: 40px auto;
            }

            .about-cta {
                flex-direction: column;
                align-items: flex-start;
                padding: 25px 22px;
            }

            .cta-button {
                width: 100%;
                justify-content: center;
            }

            footer {
                padding: 35px 20px;
            }

            .footer-grid {
                grid-template-columns: 1fr;
                gap: 24px;
            }
        }
    
        .nav-icons { display:flex; align-items:center; gap:10px; }
        .login-pill { display:inline-flex; align-items:center; justify-content:center; gap:7px; padding:10px 15px; border-radius:11px; background:linear-gradient(135deg,#f0208d,#ff3b86); color:#fff; font-size:12px; font-weight:800; text-transform:uppercase; box-shadow:0 8px 18px rgba(239,58,155,.18); transition:.25s; }
        .login-pill:hover { transform:translateY(-2px); }
        .logout-pill {
            border: 0;
            cursor: pointer;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .logout-pill:focus { outline: none; }
        .logout-popup { border-radius: 18px !important; }
        .logout-title {
            color: #102f91 !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            font-size: 24px !important;
            font-weight: 800 !important;
        }
        .logout-text {
            color: #64748b !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            font-size: 13px !important;
        }
        .logout-confirm,
        .logout-cancel {
            border-radius: 10px !important;
            padding: 10px 18px !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            font-size: 12px !important;
            font-weight: 800 !important;
        }

        .icon-btn { width:42px; height:42px; display:flex; align-items:center; justify-content:center; border:1px solid #f0208d; border-radius:50%; background:#fff; color:#f0208d; transition:.2s; }
        .icon-btn:hover { background:#fff1f8; transform:translateY(-2px); }
        @media (max-width:760px) { .nav-icons { display:none; } }
</style>
<link rel="stylesheet" href="ui_polish.css">
</head>

<body>

<nav class="navbar">
    <a href="home.php" class="logo" title="Back to Home">
        <div class="logo-main"><span class="logo-sa">SA</span><span class="logo-design">DESIGN</span></div>
        <div class="logo-subtitle">PRINTING &amp; ADVERTISING</div>
    </a>

    <div class="nav-links" id="mainNav">
        <a href="home.php">Home</a>
        <a href="home.php#products-section">Products</a>
        <a href="about.php" class="active">About Us</a>
        <a href="custom_request.php">Custom Request</a>
    </div>

    <div class="nav-icons">
        <?php if ($loggedIn): ?>
            <a href="cust_profile.php" class="login-pill" title="My profile">
                <i class="fa-regular fa-user"></i><span>Profile</span>
            </a>
            <button type="button" class="login-pill logout-pill" onclick="confirmLogout()">
                <i class="fa-solid fa-right-from-bracket"></i> Log out
            </button>
            <a href="cart.php" class="icon-btn" title="Shopping Cart" aria-label="Shopping Cart"><i class="fa-solid fa-bag-shopping"></i></a>
        <?php else: ?>
            <a href="index.php" class="login-pill"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
            <a href="index.php" class="icon-btn" title="Account" aria-label="Account"><i class="fa-solid fa-user"></i></a>
        <?php endif; ?>
    </div>

    <button type="button" class="menu-toggle" id="menuToggle" aria-label="Open menu" aria-expanded="false"><i class="fa-solid fa-bars"></i></button>
</nav>

<section class="about-hero">
    <div class="about-hero-content">
        <span class="section-badge">
            <i class="fa-solid fa-building"></i>
            ABOUT SA DESIGN
        </span>
        <h1>Printing That Brings <span>Ideas</span> to Life</h1>
        <p>
            SA Design provides quality printing and advertising solutions
            for businesses, events, schools and personal needs.
        </p>
    </div>
</section>

<main>
    <div class="section-title">
        <span class="section-badge">
            <i class="fa-solid fa-compass"></i>
            WHO WE ARE
        </span>
        <h2>Our Mission, Vision &amp; Availability</h2>
        <p>Learn more about what drives SA Design and how we serve our customers.</p>
    </div>

    <div class="about-grid">
        <section class="info-card">
            <div class="info-icon"><i class="fa-solid fa-bullseye"></i></div>
            <h2>Mission</h2>
            <p>To make SA DESIGN the leading printing center in Muadzam Shah.</p>
            <p>To open up job opportunities for young people in Muadzam Shah.</p>
        </section>

        <section class="info-card">
            <div class="info-icon"><i class="fa-solid fa-eye"></i></div>
            <h2>Vision</h2>
            <p>To become the leading provider of printing materials in Muadzam Shah by the year 2030.</p>
        </section>

        <section class="info-card">
            <div class="info-icon"><i class="fa-solid fa-clock"></i></div>
            <h2>Availability</h2>
            <p><strong>Monday – Friday</strong><br>9:00 AM – 6:00 PM</p>
            <p><strong>Saturday &amp; Sunday</strong><br>Closed. Custom request messages can be sent at any time.</p>
        </section>
    </div>

    <div class="section-title" style="margin-top:55px;">
        <span class="section-badge">
            <i class="fa-solid fa-location-dot"></i>
            FIND US
        </span>
        <h2>Visit &amp; Contact Us</h2>
        <p>Have a question or need a custom printing solution? We’re ready to help.</p>
    </div>

    <div class="bottom-grid">
        <section class="content-card">
            <h2><i class="fa-solid fa-map-location-dot"></i> Location</h2>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3787.0147704358624!2d103.08029067718353!3d3.0552928889801323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cf0bd4bf3939b%3A0x5c12ede11de0b6a3!2sPUSAT%20PERCETAKAN%20MUADZAM%20SHAH%20%7C%20SA%20DESIGN!5e1!3m2!1sen!2smy!4v1785986672640!5m2!1sen!2smy"
                allowfullscreen=""
                loading="lazy"
                referrerpolicy="strict-origin-when-cross-origin"
                title="SA Design location map">
            </iframe>
        </section>

        <section class="content-card">
            <h2><i class="fa-solid fa-address-card"></i> Contact Us</h2>

            <div class="contact-item">
                <div class="contact-icon"><i class="fa-solid fa-location-dot"></i></div>
                <div>
                    <strong>ADDRESS</strong>
                    <span>MM29, Medan Mewah, 26700 Muadzam Shah, Pahang</span>
                </div>
            </div>

            <div class="contact-item">
                <div class="contact-icon"><i class="fa-solid fa-phone"></i></div>
                <div>
                    <strong>PHONE</strong>
                    <a href="tel:+60194184147" class="contact-link">+60194184147</a>
                </div>
            </div>

            <div class="contact-item">
                <div class="contact-icon"><i class="fa-solid fa-envelope"></i></div>
                <div>
                    <strong>EMAIL</strong>
                    <a href="mailto:salamakal@gmail.com" class="contact-link">salamakal@gmail.com</a>
                </div>
            </div>
        </section>
    </div>

    <div class="about-cta">
        <div>
            <h3>Ready to bring your idea to print?</h3>
            <p>Start a custom request and tell us what you need.</p>
        </div>
        <a href="custom_request.php" class="cta-button">
            Start Custom Request
            <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>
</main>

<footer>
    <div class="footer-grid">
        <div>
            <div class="footer-brand"><span>SA</span> DESIGN</div>
            <p>Printing &amp; Advertising</p>
            <p>Quality printing solutions for business, events, school and personal needs.</p>
        </div>

        <div>
            <h4>QUICK LINKS</h4>
            <a href="home.php">Home</a>
            <a href="home.php#products-section">Products</a>
            <a href="about.php">About Us</a>
            <a href="custom_request.php">Custom Request</a>
        </div>

        <div>
            <h4>CONTACT</h4>
            <a href="https://wa.me/60194184147" target="_blank" rel="noopener">WhatsApp Us</a>
            <a href="mailto:salamakal@gmail.com">Email Us</a>
        </div>
    </div>

    <div class="footer-line">© 2026 Politeknik Muadzam Shah. All rights reserved.</div>
</footer>

<script>
function confirmLogout() {
    Swal.fire({
        title: 'Logout',
        text: 'Are you sure you want to logout?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Logout',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#f0208d',
        cancelButtonColor: '#cbd8ff',
        reverseButtons: true,
        background: '#ffffff',
        customClass: {
            popup: 'logout-popup',
            title: 'logout-title',
            htmlContainer: 'logout-text',
            confirmButton: 'logout-confirm',
            cancelButton: 'logout-cancel'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php';
        }
    });
}
</script>

<script>
const menuToggle = document.getElementById('menuToggle');
const navbar = document.querySelector('.navbar');

menuToggle.addEventListener('click', () => {
    const isOpen = navbar.classList.toggle('menu-open');
    menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    menuToggle.innerHTML = isOpen
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
});

document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navbar.classList.remove('menu-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
    });
});
</script>

</body>
</html>
