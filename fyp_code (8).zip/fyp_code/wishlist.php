<?php
session_start();

if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    $_SESSION['login_notice'] = 'Please sign in to use your wishlist.';
    header('Location: index.php');
    exit();
}

$products = [
    1 => ['name' => 'Custom Self-Inking Stamp', 'image' => 'product_images/cop.png', 'price' => 'RM 25.00 - RM 35.00'],
    2 => ['name' => 'Custom Sublimation Apparel', 'image' => 'product_images/baju1.jpg', 'price' => 'RM 29.00 - RM 36.00'],
    3 => ['name' => 'Banner & Bunting Printing', 'image' => 'product_images/banting1.jpeg', 'price' => 'RM 15.00 - RM 224.00'],
    4 => ['name' => 'Premium Wedding & Business Cards', 'image' => 'product_images/card.jpeg', 'price' => 'RM 28.00 - RM 103.00'],
    5 => ['name' => 'Outdoor Promotional Windflag', 'image' => 'product_images/windflag1.jpeg', 'price' => 'RM 190.00 - RM 310.00'],
    6 => ['name' => 'Mirrokote Product Stickers', 'image' => 'product_images/sticker1.jpeg', 'price' => 'RM 62.00 - RM 150.00']
];

if (!isset($_SESSION['wishlist']) || !is_array($_SESSION['wishlist'])) {
    $_SESSION['wishlist'] = [];
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$action = $_GET['action'] ?? '';
if ($id !== false && $id !== null && isset($products[$id])) {
    if ($action === 'toggle') {
        if (in_array($id, $_SESSION['wishlist'], true)) {
            $_SESSION['wishlist'] = array_values(array_diff($_SESSION['wishlist'], [$id]));
        } else {
            $_SESSION['wishlist'][] = $id;
        }
        $redirect = $_GET['redirect'] ?? 'wishlist.php';
        header('Location: ' . ($redirect === 'product' ? 'product.php?id=' . $id : 'wishlist.php'));
        exit();
    }
    if ($action === 'remove') {
        $_SESSION['wishlist'] = array_values(array_diff($_SESSION['wishlist'], [$id]));
        header('Location: wishlist.php');
        exit();
    }
}

$savedProducts = [];
foreach ($_SESSION['wishlist'] as $savedId) {
    if (isset($products[$savedId])) {
        $savedProducts[$savedId] = $products[$savedId];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist | SA Design</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ui_polish.css">
    <style>
        body { background:#f6e8f2; color:#172033; }
        .wishlist-page { width:min(1120px, calc(100% - 48px)); margin:48px auto 70px; }
        .wishlist-heading { display:flex; justify-content:space-between; align-items:end; gap:20px; margin-bottom:24px; }
        .wishlist-heading h1 { color:#102f91; font-size:clamp(28px,4vw,42px); letter-spacing:-1.5px; }
        .wishlist-heading p { margin-top:7px; color:#64748b; font-size:13px; }
        .wishlist-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:18px; }
        .wishlist-card { overflow:hidden; background:#fff; border:1px solid #e2e7f1; border-radius:18px; box-shadow:0 12px 30px rgba(28,53,118,.07); }
        .wishlist-card img { width:100%; height:190px; object-fit:contain; padding:18px; background:#edf3ff; }
        .wishlist-card-body { padding:17px; }
        .wishlist-card h2 { font-size:15px; color:#172033; }
        .wishlist-card p { margin:8px 0 15px; color:#f0208d; font-size:13px; font-weight:800; }
        .wishlist-actions { display:flex; gap:8px; }
        .wishlist-actions a { flex:1; padding:10px; border-radius:10px; text-align:center; font-size:11px; font-weight:800; }
        .wishlist-view { background:#edf3ff; color:#1747c7; }
        .wishlist-remove { background:#fff0f7; color:#d51b79; }
        .wishlist-empty { padding:70px 20px; text-align:center; background:#fff; border:1px solid #e2e7f1; border-radius:20px; color:#64748b; }
        .wishlist-empty i { display:block; margin-bottom:14px; color:#f0208d; font-size:40px; }
        @media(max-width:760px) { .wishlist-page { width:calc(100% - 32px); margin-top:30px; }.wishlist-heading { align-items:flex-start; flex-direction:column; }.wishlist-grid { grid-template-columns:1fr; } }
    </style>
</head>
<body>
    <main class="wishlist-page">
        <div class="wishlist-heading">
            <div><p class="eyebrow">CUSTOMER AREA</p><h1>My Wishlist</h1><p>Save products you want to order later.</p></div>
            <a class="back-btn" href="home.php">← Continue Shopping</a>
        </div>
        <?php if ($savedProducts): ?>
            <div class="wishlist-grid">
                <?php foreach ($savedProducts as $savedId => $item): ?>
                    <article class="wishlist-card">
                        <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                        <div class="wishlist-card-body">
                            <h2><?= htmlspecialchars($item['name']) ?></h2>
                            <p><?= htmlspecialchars($item['price']) ?></p>
                            <div class="wishlist-actions">
                                <a class="wishlist-view" href="product.php?id=<?= $savedId ?>">View Product</a>
                                <a class="wishlist-remove" href="wishlist.php?action=remove&id=<?= $savedId ?>">Remove</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="wishlist-empty"><i class="fa-regular fa-heart"></i><strong>Your wishlist is empty</strong><p>Add products here to find them quickly later.</p></div>
        <?php endif; ?>
    </main>
</body>
</html>
