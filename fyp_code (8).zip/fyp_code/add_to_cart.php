<?php
session_start();

/*
|--------------------------------------------------------------------------
| SA DESIGN - SECURE ADD TO CART
|--------------------------------------------------------------------------
| The browser is NOT trusted for product name, image or price.
| Product/specification prices are validated again on the server.
|--------------------------------------------------------------------------
*/

// 1. Login protection
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    $_SESSION['login_notice'] = 'Please sign in or create an account before adding items to your cart.';
    header('Location: index.php');
    exit();
}

// 2. Only POST requests are accepted
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['add_to_cart'])) {
    header('Location: home.php');
    exit();
}


// -------------------------------------------------------------------------
// 3. SERVER-SIDE PRODUCT CATALOG
//    Keep these prices synchronized with product.php.
// -------------------------------------------------------------------------

$products = [
    1 => [
        'name' => 'Custom Self-Inking Stamp',
        'image' => 'product_images/cop.png',
        'prices' => [
            'CODE 4912 (47x18mm)' => 28.00,
            'CODE 4913 (58x22mm)' => 35.00,
            'CODE 9511 (Pocket Stamp)' => 28.00,
            'CODE 4630 (Round 30mm)' => 35.00,
            'CODE 4916 (70x10mm)' => 25.00
        ]
    ],

    2 => [
        'name' => 'Custom Sublimation Apparel',
        'image' => 'product_images/baju1.jpg',
        'prices' => [
            'ROUNDNECK SHORT SLEEVE' => 29.00,
            'ROUNDNECK LONG SLEEVE' => 35.00,
            'MUSLIMAH CUT' => 36.00,
            'SHORT SLEEVE POLO COLLAR' => 34.00,
            'SHORT SLEEVE RETRO COLLAR' => 36.00
        ],
        'sizes' => ['XS','S','M','L','XL','2XL','3XL','4XL','5XL'],
        'minimum_quantity' => 15
    ],

    3 => [
        'name' => 'Banner & Bunting Printing',
        'image' => 'product_images/banting1.jpeg',
        'prices' => [
            '2 X 2 FT' => 15.00,
            '2 X 3 FT' => 21.00,
            '2 X 4 FT' => 27.00,
            '2 X 5 FT' => 34.00,
            '2 X 6 FT' => 40.00,
            '4 X 2 FT' => 25.00,
            '4 X 3 FT' => 38.00,
            '4 X 4 FT' => 51.00,
            '4 X 5 FT' => 64.00,
            '4 X 6 FT' => 76.00,
            '4 X 7 FT' => 89.00,
            '5 X 2 FT' => 32.00,
            '5 X 3 FT' => 48.00,
            '5 X 4 FT' => 64.00,
            '5 X 5 FT' => 80.00,
            '5 X 6 FT' => 96.00,
            '5 X 7 FT' => 112.00,
            '6 X 2 FT' => 38.00,
            '6 X 3 FT' => 55.00,
            '6 X 4 FT' => 75.00,
            '6 X 5 FT' => 96.00,
            '6 X 6 FT' => 115.00,
            '6 X 7 FT' => 134.00,
            '7 X 2 FT' => 41.00,
            '7 X 3 FT' => 62.00,
            '7 X 4 FT' => 83.00,
            '7 X 5 FT' => 104.00,
            '7 X 6 FT' => 125.00,
            '7 X 7 FT' => 146.00,
            '8 X 2 FT' => 51.00,
            '8 X 3 FT' => 76.00,
            '8 X 4 FT' => 99.00,
            '8 X 5 FT' => 128.00,
            '8 X 6 FT' => 153.00,
            '8 X 7 FT' => 179.00,
            '9 X 2 FT' => 57.00,
            '9 X 3 FT' => 86.00,
            '9 X 4 FT' => 115.00,
            '9 X 5 FT' => 144.00,
            '9 X 6 FT' => 172.00,
            '9 X 7 FT' => 201.00,
            '10 X 2 FT' => 64.00,
            '10 X 3 FT' => 96.00,
            '10 X 4 FT' => 120.00,
            '10 X 5 FT' => 160.00,
            '10 X 6 FT' => 192.00,
            '10 X 7 FT' => 224.00
        ]
    ],

    4 => [
        'name' => 'Premium Wedding & Business Cards',
        'image' => 'product_images/card.jpeg',
        'prices' => [
            'SOFT TOUCH|100 PCS' => 28.00,
            'SOFT TOUCH|200 PCS' => 42.00,
            'SOFT TOUCH|300 PCS' => 51.00,
            'SOFT TOUCH|500 PCS' => 71.00,
            'SOFT TOUCH|1000 PCS' => 88.00,
            'GLOSSY TYPE|100 PCS' => 37.00,
            'GLOSSY TYPE|200 PCS' => 53.00,
            'GLOSSY TYPE|300 PCS' => 57.00,
            'GLOSSY TYPE|500 PCS' => 79.00,
            'GLOSSY TYPE|1000 PCS' => 103.00
        ]
    ],

    5 => [
        'name' => 'Outdoor Promotional Windflag',
        'image' => 'product_images/windflag1.jpeg',
        'prices' => [
            '3.4 METERS|HAS ARTWORK' => 190.00,
            '3.4 METERS|REQUIRES DESIGN' => 220.00,
            '5.0 METERS|HAS ARTWORK' => 280.00,
            '5.0 METERS|REQUIRES DESIGN' => 310.00
        ]
    ],

    6 => [
        'name' => 'Mirrokote Product Stickers (Round & Square)',
        'image' => 'product_images/sticker1.jpeg',
        'prices' => [
            '3 CM|100 PCS' => 62.00,
            '3 CM|200 PCS' => 65.00,
            '3 CM|300 PCS' => 67.00,
            '3 CM|500 PCS' => 80.00,
            '3 CM|1000 PCS' => 89.00,

            '4 CM|100 PCS' => 74.00,
            '4 CM|200 PCS' => 77.00,
            '4 CM|300 PCS' => 81.00,
            '4 CM|500 PCS' => 87.00,
            '4 CM|1000 PCS' => 105.00,

            '5 CM|100 PCS' => 75.00,
            '5 CM|200 PCS' => 82.00,
            '5 CM|300 PCS' => 87.00,
            '5 CM|500 PCS' => 97.00,
            '5 CM|1000 PCS' => 124.00,

            '6 CM|100 PCS' => 77.00,
            '6 CM|200 PCS' => 85.00,
            '6 CM|300 PCS' => 93.00,
            '6 CM|500 PCS' => 108.00,
            '6 CM|1000 PCS' => 150.00
        ]
    ]
];


// -------------------------------------------------------------------------
// 4. Validate Product ID
// -------------------------------------------------------------------------

$product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

if (
    $product_id === false ||
    $product_id === null ||
    !isset($products[$product_id])
) {
    $_SESSION['cart_error'] = 'Invalid product selected.';
    header('Location: home.php');
    exit();
}

$product = $products[$product_id];


// -------------------------------------------------------------------------
// 5. Validate Quantity
// Apparel requires a minimum order of 15 PCS, matching product.php.
// -------------------------------------------------------------------------

$quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

if ($quantity === false || $quantity === null) {
    $quantity = 1;
}

if ($quantity < 1 || $quantity > 999) {
    $_SESSION['cart_error'] = 'Quantity must be between 1 and 999.';
    header('Location: product.php?id=' . $product_id);
    exit();
}

if (
    isset($product['minimum_quantity']) &&
    $quantity < $product['minimum_quantity']
) {
    $_SESSION['cart_error'] =
        'This product requires a minimum order of ' .
        $product['minimum_quantity'] . ' PCS.';

    header('Location: product.php?id=' . $product_id);
    exit();
}


// -------------------------------------------------------------------------
// 6. Read the selected specification from the submitted fields
// -------------------------------------------------------------------------

$size = trim($_POST['size'] ?? '');
$details = trim($_POST['details'] ?? '');


// -------------------------------------------------------------------------
// 7. Determine EXACT server-side price
// -------------------------------------------------------------------------

$server_price = null;
$validated_variant = '';

if ($product_id === 1) {

    // Stamp: size contains the exact code/model.
    $stamp_code = $size;

    if (!isset($product['prices'][$stamp_code])) {
        $_SESSION['cart_error'] = 'Invalid stamp model selected.';
        header('Location: product.php?id=1');
        exit();
    }

    $server_price = $product['prices'][$stamp_code];
    $validated_variant = $stamp_code;


} elseif ($product_id === 2) {

    // Apparel: size is "TYPE / SIZE".
    $parts = array_map('trim', explode('/', $size, 2));
    $type = trim($parts[0] ?? '');
    $apparel_size = strtoupper(trim($parts[1] ?? ''));

    if (!isset($product['prices'][$type])) {
        $_SESSION['cart_error'] = 'Invalid apparel type selected.';
        header('Location: product.php?id=2');
        exit();
    }

    if (!in_array($apparel_size, $product['sizes'], true)) {
        $_SESSION['cart_error'] = 'Invalid apparel size selected.';
        header('Location: product.php?id=2');
        exit();
    }

    $server_price = $product['prices'][$type];
    $validated_variant = $type . ' / ' . $apparel_size;


} elseif ($product_id === 3) {

    // Banner: size is the exact dimension.
    if (!isset($product['prices'][$size])) {
        $_SESSION['cart_error'] = 'Invalid banner dimension selected.';
        header('Location: product.php?id=3');
        exit();
    }

    $server_price = $product['prices'][$size];
    $validated_variant = $size;


} elseif ($product_id === 4) {

    // Cards: size is "FINISHING / PACKAGE".
    $parts = array_map('trim', explode('/', $size, 2));
    $finishing = $parts[0] ?? '';
    $package = $parts[1] ?? '';

    $key = $finishing . '|' . $package;

    if (!isset($product['prices'][$key])) {
        $_SESSION['cart_error'] = 'Invalid card finishing or package selected.';
        header('Location: product.php?id=4');
        exit();
    }

    $server_price = $product['prices'][$key];
    $validated_variant = $finishing . ' / ' . $package;


} elseif ($product_id === 5) {

    // Windflag: size is "HEIGHT / DESIGN OPTION".
    $parts = array_map('trim', explode('/', $size, 2));
    $height = $parts[0] ?? '';
    $design = strtoupper($parts[1] ?? '');

    $key = $height . '|' . $design;

    if (!isset($product['prices'][$key])) {
        $_SESSION['cart_error'] = 'Invalid windflag option selected.';
        header('Location: product.php?id=5');
        exit();
    }

    $server_price = $product['prices'][$key];
    $validated_variant = $height . ' / ' . $design;


} elseif ($product_id === 6) {

    // Sticker: size is "SHAPE / SIZE / PACKAGE".
    $parts = array_map('trim', explode('/', $size, 3));
    $shape = $parts[0] ?? '';
    $sticker_size = $parts[1] ?? '';
    $package = $parts[2] ?? '';

    // Shape is intentionally not part of the price because the current
    // product.php uses the same price table for Round and Square.
    if (!in_array($shape, ['ROUND', 'SQUARE'], true)) {
        $_SESSION['cart_error'] = 'Invalid sticker shape selected.';
        header('Location: product.php?id=6');
        exit();
    }

    $key = $sticker_size . '|' . $package;

    if (!isset($product['prices'][$key])) {
        $_SESSION['cart_error'] = 'Invalid sticker size or package selected.';
        header('Location: product.php?id=6');
        exit();
    }

    $server_price = $product['prices'][$key];
    $validated_variant = $shape . ' / ' . $sticker_size . ' / ' . $package;
}


// -------------------------------------------------------------------------
// 8. Final price check
// -------------------------------------------------------------------------

if ($server_price === null) {
    $_SESSION['cart_error'] = 'Unable to validate the product price.';
    header('Location: product.php?id=' . $product_id);
    exit();
}


// -------------------------------------------------------------------------
// 9. Sanitize details
// -------------------------------------------------------------------------

$details = mb_substr($details, 0, 1200);


// -------------------------------------------------------------------------
// 10. Generate a safe cart item ID
// -------------------------------------------------------------------------

$cart_item_id = trim($_POST['cart_item_id'] ?? '');

if (
    $cart_item_id === '' ||
    !preg_match('/^[a-zA-Z0-9_-]{1,100}$/', $cart_item_id)
) {
    $cart_item_id =
        $product_id . '-' .
        time() . '-' .
        bin2hex(random_bytes(4));
}


// -------------------------------------------------------------------------
// 11. Create cart
// -------------------------------------------------------------------------

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


// -------------------------------------------------------------------------
// 12. Add/update item
// -------------------------------------------------------------------------

if (isset($_SESSION['cart'][$cart_item_id])) {

    $new_quantity =
        (int)$_SESSION['cart'][$cart_item_id]['quantity'] +
        $quantity;

    $_SESSION['cart'][$cart_item_id]['quantity'] =
        min(999, $new_quantity);

} else {

    $_SESSION['cart'][$cart_item_id] = [
        'product_id' => $product_id,

        // IMPORTANT:
        // Product name and image come from the server catalog.
        'name' => $product['name'],
        'image' => $product['image'],

        // IMPORTANT:
        // Price comes from exact server-side option validation.
        'price' => round($server_price, 2),

        'size' => $validated_variant,
        'details' => $details,
        'quantity' => $quantity
    ];
}


// -------------------------------------------------------------------------
// 13. Success message
// -------------------------------------------------------------------------

$_SESSION['cart_success'] =
    $product['name'] . ' added to cart successfully.';


// -------------------------------------------------------------------------
// 14. Redirect
// -------------------------------------------------------------------------

header('Location: cart.php');
exit();
?>